﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PermanenteEvalutieMocking
{
    public class WorldTime
    {
        public string DateTime { get; set; }
        public string TimeZone { get; set; }

        
    }
}
